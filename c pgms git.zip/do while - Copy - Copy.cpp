#include <stdio.h>

int main() {
    int i = 0;

    do {
        printf("do...while loop: i = %d\n", i);
        i++;
    } while (i > 5);

    return 0;
}
