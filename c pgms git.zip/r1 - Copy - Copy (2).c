#include<stdio.h>
main()
{
	int a,b,c,d,maxof3,maxof4;
	printf("\n enter a b c values");
	scanf("%d %d %d %d",&a,&b,&c,&d);		
	maxof3= a>b? (a>c? a : c) : (b>c? b : c);
	maxof4=maxof3>d? maxof3 : d;
	printf("\n %d",maxof4);
}

