#include <stdio.h>
int main() {
	int israin=0;
	if(! israin)
	{
		printf("go outside");
	}
	return 0;
}
