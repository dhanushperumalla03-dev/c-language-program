#include <stdio.h>
#include <math.h>
int main(){
	int a,b,Area;
	printf("enter a : ");
	scanf("%d",&a);
	printf("enter b : ");
	scanf("%d",&b);
	Area = a*b ;
	printf("%d",Area);
}
