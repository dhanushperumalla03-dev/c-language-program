#include <stdio.h>
int fact(int n) {
	if(n<=1)
	{
		return 1;
	}
	return n * fact(n-1);
}

int main()
{
	int n;
	printf("Enter a num: ");
	scanf("%d",&n);
	printf("fact of %d is %d",n,fact(n));
	return 0;
}
