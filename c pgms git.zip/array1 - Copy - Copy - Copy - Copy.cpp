#include <stdio.h>
int main (){
	int i,student[75]={16,10,15,12,4};
	for(i=0;i<=4 ;i++)
	{
		printf("%d\n",student[i]);
	}
	return 0;
}
