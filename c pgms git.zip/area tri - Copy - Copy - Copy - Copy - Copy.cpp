#include <stdio.h>
int main(){
	float a,b,Area;
	printf("enter a : ");
	scanf("%f",&a);
	printf("enter b : ");
	scanf("%f",&b);
	Area =0.5*a*b ;
	printf("%f",Area);
}
