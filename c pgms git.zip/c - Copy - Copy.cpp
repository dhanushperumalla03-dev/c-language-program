#include<stdio.h>
int main()
{
	int a;
	int b;
	printf("enter value of a:");
	scanf("%d",&a);
	printf("enter value of b :");
	scanf("%d",&b);
	printf("sum of a and b %d",a+b);
	return 0;
	}
