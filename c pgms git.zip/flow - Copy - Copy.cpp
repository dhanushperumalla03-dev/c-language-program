#include <stdio.h>
int main() {
	int i, j, k;
i = 3;

j = -3;

k += j;

k = i *j;


k /= i;
printf("%d",k);
	return 0;
}
